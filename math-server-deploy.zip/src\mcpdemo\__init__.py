"""MCP Demo Package using FastMCP

A simple demonstration of Model Context Protocol servers and clients using FastMCP.
"""

__version__ = "0.1.0"
__author__ = "MCP Demo"